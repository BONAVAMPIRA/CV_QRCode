# ROADMAP — qrcode-cv (CV_QRCode)

## Phase 0 — Mise en place (session 1)
- [ ] Kit déposé dans `C:\cv-networking` (PAS dans `C:\Jaona\Perso\CV\QR Code CV`)
- [ ] `bash .claude/scripts/handshake.sh` exécuté à la main une fois → vérifier que
  l'état git + dernier déploiement s'affichent
- [ ] Session Claude Code test : le contexte s'injecte automatiquement au démarrage
**Critère de passage** : Claude Code démarre en sachant qu'on est en plein P0 sécurité,
sans qu'on lui explique rien.

## Phase 1 — P0 Sécurité (PRIORITÉ ABSOLUE — avant tout le reste)
Objectif : le mot de passe admin n'est plus exposé, ni dans le code ni dans l'historique git public.
- [ ] Backup : clone séparé du repo actuel (avant toute opération destructive)
- [ ] Nouveau mot de passe admin choisi (ne jamais réutiliser l'ancien)
- [ ] Variable d'env créée (Vercel + `.env.local`), code modifié pour la lire
- [ ] Validation `reviewer` : confirme que le secret n'est plus en dur nulle part
- [ ] Purge de l'historique git (`git filter-repo` ou BFG) + force-push
- [ ] Vérification RÉELLE sur l'interface web GitHub : l'ancien mot de passe n'apparaît
  plus dans aucun commit visible de l'historique
- [ ] Déploiement Vercel avec la nouvelle variable d'env, test de connexion admin réel
**Critère de passage** : mot de passe absent du code ET de l'historique git visible sur
GitHub, page admin fonctionnelle avec le nouveau mot de passe.

## Phase 2 — Réparer l'envoi de mail (migration vers Resend)
Objectif : le CV est réellement envoyé par mail à la personne qui scanne le QR code.
- [ ] Compte Resend créé (ou récupéré si déjà existant depuis l'ancien zip de référence)
- [ ] Domaine vérifié sur Resend (DNS)
- [ ] `/api/send-email` modifié : remplacement du transport nodemailer/Gmail SMTP par
  l'API Resend
- [ ] Variables d'env Gmail (`GMAIL_USER`, `GMAIL_APP_PASSWORD`) retirées, remplacées
  par la clé API Resend
- [ ] Validation `reviewer` avant déploiement (secrets, gestion d'erreur, pas de swallow silencieux)
- [ ] Déploiement Vercel
- [ ] **Test réel** : scanner le QR code en conditions réelles (ou simuler le flow complet),
  vérifier que l'email arrive bien dans une boîte de réception réelle — pas juste un
  statut HTTP 200
**Critère de passage** : un email avec le CV est réellement reçu après un scan réel du QR code.

## Phase 3 — Durcissement
Objectif : `/api/send-email` n'est pas un vecteur de spam/abus.
- [ ] Rate limiting basique sur l'endpoint (par IP ou par email destinataire)
- [ ] Validation du format email côté serveur (pas seulement côté client)
- [ ] Validation `reviewer`
**Critère de passage** : l'endpoint refuse les abus évidents (spam de requêtes, emails invalides).

## Phase 4 — Feature additionnelle (à définir avec Jaona en session)
Objectif : [à préciser — Jaona décrira la feature directement en session Claude Code]
- [ ] Description de la feature obtenue auprès de Jaona
- [ ] `propagateur` : analyse d'impact sur le flow existant avant de coder
- [ ] Implémentation
- [ ] Validation `reviewer`
**Critère de passage** : à définir une fois la feature connue.

## Phase finale — Clôture
- [ ] Tests complets passants (flow QR → affichage → capture → envoi mail, de bout en bout)
- [ ] PROJECT_CONTEXT.md à jour (décisions, état final)
- [ ] `/retro` exécuté (learning tracker mis à jour : sécurité, intégrations API)
- [ ] Composants génériques promus vers `_shared\` si applicable (ex: adapter Resend)
- [ ] `/save` final

## Si dérive
- +30% de temps vs estimation → STOP, analyse, replanification (pas d'acharnement)
- Un module résiste après 3 tentatives → on l'isole et on le réécrit from scratch
- La purge d'historique git rate ou casse le repo → restaurer depuis le backup (Phase 1),
  ne jamais forcer une seconde tentative sans comprendre l'échec de la première
