# learnings.md — Journal de formation Jaona (qrcode-cv)
> SOURCE UNIQUE d'apprentissage. Chaque session y ajoute ce que Jaona a
> découvert, décidé, questionné.

---
## Session 0 (Cabinet — avant Claude Code)
### Concepts découverts
- Le dossier de travail supposé (`QR Code CV`) n'était pas le code réel — leçon :
  toujours vérifier `git remote -v` et l'emplacement réel avant de supposer.
- Gmail SMTP est structurellement fragile depuis un environnement serverless (Vercel) :
  Google applique du rate limiting/blocage qui n'apparaît pas en dev local.
### Décisions
- P0 sécurité (mdp admin en clair sur repo public) traité avant le bug fonctionnel.
- Migration directe vers Resend plutôt que tentative de réparation Gmail SMTP.
### Questions ouvertes
- Détail de la feature additionnelle à définir en session Claude Code.
